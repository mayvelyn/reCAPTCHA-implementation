<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Contacts</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <div class="container">
            <div>
                <div>
                    <h1>Mayvelyn Cereno</h1>
                </div>
                <div>
                    <a href="https://www.facebook.com/mayvelyn.cereno">https://www.facebook.com/mayvelyn.cereno</a>
                </div>
                <div class="center">
                    <a href="login.php" class="button-81">Back</a>
                </div>
            </div>
        </div>

        <script src="script.js"></script>
        
    </body>

</html>
