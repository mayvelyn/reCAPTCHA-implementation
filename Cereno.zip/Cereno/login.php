<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="style.css">
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    </head>

    <body>

        <div class="login-box">
            <h2>Login</h2>
            <form id="form" method="POST">
                <div class="user-box">
                    <input type="text" id="user_name" name="username" required="">
                    <label>Username</label>
                </div>
                <div class="user-box">
                    <input type="password" id="pass_word" name="password" required="">
                    <label>Password</label>
                </div>
                
                <div class="g-recaptcha" data-sitekey="6LclyEoqAAAAAMu5Bk0MQXpWIKEMHSbutmwhRlOR"></div>

                <div class="center">
                    <button class="button-81" type="submit">Login</button>
                </div>
            </form>
        </div>

        <script src="script.js"></script>

    </body>
    
</html>
