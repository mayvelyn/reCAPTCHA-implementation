document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault();

    var recaptchaResponse = grecaptcha.getResponse();
    var user_name = document.getElementById('user_name').value;
    var pass_word = document.getElementById('pass_word').value;

    if (recaptchaResponse.length === 0) {
        alert("Please complete the reCAPTCHA.");
        return;
    }

    if (user_name === "mayvelyn" && pass_word === "maganda") {
        window.location.href = "contact.php";
    } else {
        alert("Incorrect Username and Password");
    }
    
});
